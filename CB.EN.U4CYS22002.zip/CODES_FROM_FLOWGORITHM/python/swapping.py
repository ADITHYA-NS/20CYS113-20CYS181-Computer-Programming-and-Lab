print("Enter the value for a:")
a = int(input())
print("Enter the value for b:")
b = int(input())
print("Values of a and b before swapping")
print("a=" + str(a))
print("b=" + str(b))

# to swap a and b
a = a + b
b = a - b
a = a - b
print("Values of a and b after swapping")
print("a=" + str(a))
print("b=" + str(b))
