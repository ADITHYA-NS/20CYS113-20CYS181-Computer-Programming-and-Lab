# to find the frequencyn of a number in an array
array = [0] * (10)

# loop to input array
for i in range(0, 9 + 1, 1):
    print("Enter number:")
    num = int(input())
    array[i] = num
print("Enter the value of number whose frequency is to be found:")
val = int(input())
count = 0

# loop to find the frequency of the number in array
for i in range(0, 9 + 1, 1):
    if array[i] == val:
        count = count + 1
print("Frequency of " + str(val) + "=" + str(count))
