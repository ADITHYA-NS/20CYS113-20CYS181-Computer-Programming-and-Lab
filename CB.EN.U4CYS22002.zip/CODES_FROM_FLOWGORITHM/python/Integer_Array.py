# to create an array  with size 10 of integers
array = [0] * (10)

# loop to append values into the array
for i in range(0, 9 + 1, 1):
    print("Enter number:")
    num = int(input())
    array[i] = num
print("Array contents:")

# loop to output the values from the array
for i in range(0, 9 + 1, 1):
    print("Array" + "[" + str(i) + "]" + "=" + str(array[i]))
