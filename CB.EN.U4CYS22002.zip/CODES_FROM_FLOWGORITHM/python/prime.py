prime = "IS PRIME"
n = int(input())
for i in range(2, n - 1 + 1, 1):
    if n % i == 0:
        prime = "NOT PRIME"
print(prime)
