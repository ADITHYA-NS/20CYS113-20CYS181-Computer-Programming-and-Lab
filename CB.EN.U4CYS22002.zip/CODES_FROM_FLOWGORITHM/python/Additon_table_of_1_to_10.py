# to find th addition table from 1 to 10
# Initially sum is zero
sum = 0

# num1 takes values from 1 to 10 in each iteration.
for num1 in range(1, 10 + 1, 1):
    
    # Gives the addition table for each value of num1
    print("Addition Table of " + str(num1))
    
    # num2 takes values from 1-10
    for num2 in range(1, 10 + 1, 1):
        sum = num1 + num2
        print(str(num1) + "+" + str(num2) + "=" + str(sum))
