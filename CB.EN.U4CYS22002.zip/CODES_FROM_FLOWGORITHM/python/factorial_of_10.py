# to find the factorial of 10
# initially factorial is one
fact = 1

# num takes the values from 1 to 10 in each iteration
for num in range(1, 10 + 1, 1):
    fact = fact * num
print("Factorial of 10:" + str(fact))
