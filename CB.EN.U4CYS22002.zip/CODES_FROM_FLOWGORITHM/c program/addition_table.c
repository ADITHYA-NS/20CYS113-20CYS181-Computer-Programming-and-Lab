
#include <stdio.h>

int main() {
    int sum = 0;
    int num1, num2;
    for (num1 = 1; num1 <= 10; num1++) {
        printf("Addition Table of %d\n", num1);
        for (num2 = 1; num2 <= 10; num2++) {
            sum = num1 + num2;
            printf("%d + %d = %d\n", num1, num2, sum);
        }
    }
    return 0;
}
