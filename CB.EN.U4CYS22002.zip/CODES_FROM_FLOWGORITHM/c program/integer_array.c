#include <stdio.h>

int main() {
    int array[10];
    int i;
    for (i = 0; i <= 9; i++) {
        printf("Enter number: ");
        scanf("%d", &array[i]);
    }
    printf("Array contents:\n");
    for (i = 0; i <= 9; i++) {
        printf("Array[%d] = %d\n", i, array[i]);
    }
    return 0;
}



