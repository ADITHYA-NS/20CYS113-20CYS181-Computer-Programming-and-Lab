
#include <stdio.h>

int main() {
    int fact = 1;
    int num;
    for (num = 1; num <= 10; num++) {
        fact = fact * num;
    }
    printf("Factorial of 10: %d", fact);
    return 0;
}
