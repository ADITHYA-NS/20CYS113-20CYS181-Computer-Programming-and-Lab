
#include <stdio.h>

int main() {
    int count, num = 1, num1 = 1, temp;
    printf("Enter the number you want: ");
    scanf("%d", &count);
    printf("%d\n", num);
    while (count > 1) {
        printf("%d\n", num1);
        temp = num1;
        num1 += num;
        num = temp;
        count--;
    }
    return 0;
}

