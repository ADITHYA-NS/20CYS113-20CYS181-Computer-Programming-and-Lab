#include <stdio.h>

int main() {
    int a, b;
    printf("Enter the value for a: ");
    scanf("%d", &a);
    printf("Enter the value for b: ");
    scanf("%d", &b);
    printf("Values of a and b before swapping:\n");
    printf("a=%d\n", a);
    printf("b=%d\n", b);

    // swapping the values of a and b
    a = a + b;
    b = a - b;
    a = a - b;

    printf("Values of a and b after swapping:\n");
    printf("a=%d\n", a);
    printf("b=%d\n", b);
    return 0;
}




