#include <stdio.h>

int main() {
    int array[10];
    int i, val, count = 0;
    for (i = 0; i <= 9; i++) {
        printf("Enter number: ");
        scanf("%d", &array[i]);
    }
    printf("Enter the value of number whose frequency is to be found: ");
    scanf("%d", &val);
    for (i = 0; i <= 9; i++) {
        if (array[i] == val) {
            count++;
        }
    }
    printf("Frequency of %d = %d", val, count);
    return 0;
}


